# Deew Shop — PWA
Este pacote contém o aplicativo PWA da Deew Shop (sem dados pessoais).

## Publicação rápida (Netlify)
1. Acesse https://app.netlify.com/ e faça login.
2. Add new site → Deploy manually.
3. Envie todos os arquivos desta pasta (descompactados).
4. Após publicar, habilite HTTPS (já vem por padrão) e acesse a URL.

## Instalação no celular (Android)
1. Abra a URL no Chrome.
2. Menu do navegador → Adicionar à tela inicial.

## Observações
- O app não contém nenhum nome pessoal, apenas a marca "Deew Shop".
- WhatsApp dos pedidos: 5511988289671
- Chave Pix: ad58bf60-dcbb-4670-979c-2ced8b857d28
